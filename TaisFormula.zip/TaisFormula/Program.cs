﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace TaisFormula
{
    class Program
    {
        static void Main(string[] args)
        {
        
            int n;
            Dictionary<int, decimal> dict =new Dictionary<int , decimal>();

            n= Int32.Parse(Console.ReadLine());

            for(int i = 0; i < n; i++){
                string[] scanf = Console.ReadLine().Split();
                int ti= Int32.Parse(scanf[0]);
                decimal vi= Decimal.Parse(scanf[1]);

                dict.Add(ti, vi);
            }

            decimal answer= 0;
            for(int i = 1; i < dict.Count; i++){
                decimal fractionAnswer= (dict.ElementAt(i-1).Value + dict.ElementAt(i).Value)/ 2;
                decimal answer2 =(dict.ElementAt(i).Key - dict.ElementAt(i-1).Key);
                answer+= fractionAnswer * answer2;

            }

            Console.WriteLine(answer/1000);


        }
    }
}
