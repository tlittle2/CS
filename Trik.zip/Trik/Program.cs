﻿using System;

namespace Trik
{
    class Program
    {
        static void Main(string[] args)
        {

            string n= Console.ReadLine();
            int position= 1;

            foreach(char c in n){
                if(c.Equals('A')){
                    if(position == 1){
                        position+=1;
                    
                    }else if (position==2){
                        position-=1;
                    }

                }else if(c.Equals('B')){
                    if(position == 2){
                        position+=1;
                    }else if(position==3){
                        position-=1;
                    }
                
                }else if(c.Equals('C')){
                    if(position == 3){
                        position-=2;

                    }else if(position ==1){
                        position+=2;
                    }
                }
                
            }
            Console.WriteLine(position);  
   
        }
    }
}

