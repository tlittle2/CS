﻿using System;

namespace leftbeehind
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true){
                string[] scanf= Console.ReadLine().Split();
                int x= Int32.Parse(scanf[0]);
                int y= Int32.Parse(scanf[1]);

                if(x == 0 && y== 0){
                    break;
                }

                if(x > y){
                    if(x + y == 13){
                        Console.WriteLine("Never speak again.");
                    }else{
                        Console.WriteLine("To the convention.");
                    }
                }

                if(x < y){
                    if(x + y == 13){
                        Console.WriteLine("Never speak again.");
                    }else{
                        Console.WriteLine("Left beehind.");
                    }
                }

                if(x == y){
                    Console.WriteLine("Undecided.");
                }

            }
        }
    }
}
