﻿using System;

namespace SodaSlurper
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] scanf = Console.ReadLine().Split();

            int empties= Int32.Parse(scanf[0]);
            int pickedUp= Int32.Parse(scanf[1]);
            int needed= Int32.Parse(scanf[2]);

            int total = 0;

            int totalEmpties = empties + pickedUp;

            while(totalEmpties >= needed){
                totalEmpties-=needed;
                total++;
                totalEmpties++;

            }

            Console.WriteLine(total); 
            
        }
    }
}
