﻿using System;

namespace JudgingMoose
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] scanf = Console.ReadLine().Split();

            int a= Int32.Parse(scanf[0]);
            int b= Int32.Parse(scanf[1]);

            int answer = Math.Max(a,b) *2;

            if(answer == 0){
                Console.WriteLine($"Not a moose");

            }else if(a == b){
                Console.WriteLine($"Even {answer}");
            }else{
                Console.WriteLine($"Odd {answer}");
            }


        }
    }
}
