﻿using System;
using System.Collections.Generic; 
using System.Linq;

namespace Zoo
{
    class Program
    {
        static void Main(string[] args)
        {
            int listValue= 0;
            while (true){
                int n = Int32.Parse(Console.ReadLine());
                if(n == 0){
                    break;
                }

                listValue++;
                Dictionary<string, int> dict = new Dictionary<string, int>();
                
                for(int i = 0; i < n; i++){
                    string[] scanf = Console.ReadLine().Split();
                    
                    string animal= scanf[scanf.Length -1].ToLower();

                    if(!(dict.ContainsKey(animal))){
                        dict.Add(animal, 1);
                    }else{
                        dict[animal] +=1;
                    }
                }
                var list = dict.Keys.ToList();
                list.Sort();
                
                Console.WriteLine("List " + listValue + ":");
                
                foreach(var key in list){
                    
                    Console.WriteLine("{0} | {1}", key, dict[key]);
                }
            
            }
        }
    }

}
            

