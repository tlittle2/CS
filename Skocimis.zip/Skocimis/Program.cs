﻿using System;

namespace JudgingMoose
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] scanf = Console.ReadLine().Split();

            int a= Int32.Parse(scanf[0]);
            int b= Int32.Parse(scanf[1]);
            int c= Int32.Parse(scanf[2]);

            int bToc= (c-b)-1;

            int aTob = (b-a)-1;
            
            if(bToc > aTob){
                Console.WriteLine(bToc);
            }else{
                Console.WriteLine(aTob);
            }

        }
    }
}

