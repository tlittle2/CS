using System;
namespace Name{

    public class Program{

        public static void Main(string[] args){
            Console.WriteLine("Hello World");

        }
    }
    
}