﻿using System;

namespace JustAMinute
{
    class Program
    {
        static void Main(string[] args)
        {
            int n= Int32.Parse(Console.ReadLine());

            int mTotal =0;
            int sTotal= 0;
            for(int i = 0; i < n; i++){
                string[] scanf = Console.ReadLine().Split();
                int m= Int32.Parse(scanf[0]);
                int s= Int32.Parse(scanf[1]);

                mTotal+= m * 60;
                sTotal+=s;



            }

            double total = sTotal / mTotal;

            if(total <= 1){
                Console.WriteLine("measurement error");
            }
            Console.WriteLine(total);
            //stupid rounding
        }
    }
}
